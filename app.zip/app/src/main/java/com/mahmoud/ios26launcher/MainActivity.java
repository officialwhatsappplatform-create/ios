package com.mahmoud.ios26launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.text.TextWatcher;
import android.text.Editable;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, appGrid, dock;
    EditText search;
    ArrayList<ResolveInfo> allApps = new ArrayList<>();
    PackageManager pm;
    int page = 0;
    float downX, downY;
    int[] palette = {0xFF20264C, 0xFF334B79, 0xFF6C5A94, 0xFF172D4B};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        pm = getPackageManager();
        getWindow().setStatusBarColor(Color.rgb(24,28,57));
        getWindow().setNavigationBarColor(Color.rgb(13,16,36));
        loadApps();
        buildUI();
    }

    void loadApps() {
        Intent i = new Intent(Intent.ACTION_MAIN, null);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        allApps = new ArrayList<>(pm.queryIntentActivities(i, 0));
        Collections.sort(allApps, (a,b) -> pm.getApplicationLabel(a.activityInfo.applicationInfo).toString()
                .compareToIgnoreCase(pm.getApplicationLabel(b.activityInfo.applicationInfo).toString()));
    }

    GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(1, stroke);
        return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }

    void buildUI() {
        root = vertical();
        root.setPadding(dp(18), dp(14), dp(18), dp(12));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF141A39,0xFF3C4F79,0xFF7D6C9B,0xFF19284A}));
        setContentView(root);

        LinearLayout status = horizontal();
        TextView clock = text(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()), 16, Color.WHITE, true);
        status.addView(clock, new LinearLayout.LayoutParams(0, -2, 1));
        status.addView(text("●  ▰  Wi-Fi", 12, 0xFFE8F5FF, true));
        root.addView(status);

        TextView date = text(new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(new Date()), 14, 0xFFE3E9FF, false);
        date.setGravity(Gravity.CENTER); date.setPadding(0, dp(16), 0, dp(10)); root.addView(date);

        LinearLayout widgetRow = horizontal();
        LinearLayout bigWidget = vertical(); bigWidget.setPadding(dp(16),dp(14),dp(12),dp(12));
        bigWidget.setBackground(shape(0x553FFFFFF, dp(25), 0x66FFFFFF));
        TextView weather = text("☀", 32, Color.WHITE, true);
        bigWidget.addView(weather);
        bigWidget.addView(text("أهلاً بك", 19, Color.WHITE, true));
        bigWidget.addView(text("واجهة زجاجية لهاتفك", 11, 0xFFE5ECFF, false));
        widgetRow.addView(bigWidget, new LinearLayout.LayoutParams(0, dp(128), 1.2f));
        LinearLayout mini = vertical(); mini.setGravity(Gravity.CENTER); mini.setPadding(dp(8),dp(8),dp(8),dp(8));
        mini.setBackground(shape(0x44FFFFFF, dp(24), 0x66FFFFFF));
        mini.addView(text("◷", 28, Color.WHITE, true));
        mini.addView(text(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()), 20, Color.WHITE, true));
        mini.addView(text("الساعة", 11, 0xFFE5ECFF, false));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0,dp(128),0.8f); mp.setMargins(dp(9),0,0,0);
        widgetRow.addView(mini, mp); root.addView(widgetRow);

        search = new EditText(this);
        search.setSingleLine(true); search.setTextColor(Color.WHITE); search.setHintTextColor(0xFFDDE5FF);
        search.setHint("⌕  ابحث عن تطبيق"); search.setTextSize(14);
        search.setPadding(dp(16),0,dp(16),0); search.setBackground(shape(0x44FFFFFF,dp(24),0x66FFFFFF));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,dp(46)); sp.setMargins(0,dp(15),0,dp(10));
        root.addView(search,sp);

        TextView label = text("تطبيقاتي", 18, Color.WHITE, true);
        label.setPadding(dp(2),dp(2),0,dp(7)); root.addView(label);

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false);
        appGrid = vertical(); appGrid.setPadding(0,dp(2),0,dp(4)); scroll.addView(appGrid);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        dock = horizontal(); dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(7),dp(9),dp(7),dp(9));
        dock.setBackground(shape(0x66FFFFFF,dp(27),0x66FFFFFF));
        LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(-1,dp(76)); dp1.setMargins(0,dp(10),0,0);
        root.addView(dock,dp1);

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int start,int before,int count){ renderApps(s.toString()); }
            public void afterTextChanged(Editable e){}
        });
        renderApps("");
    }

    void renderApps(String query) {
        appGrid.removeAllViews(); dock.removeAllViews();
        ArrayList<ResolveInfo> shown = new ArrayList<>();
        for (ResolveInfo ri: allApps) {
            String name = pm.getApplicationLabel(ri.activityInfo.applicationInfo).toString();
            if (name.toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT))) shown.add(ri);
        }
        int columns = 4;
        for (int i=0; i<shown.size(); i+=columns) {
            LinearLayout row = horizontal(); row.setGravity(Gravity.TOP); row.setPadding(0,dp(7),0,dp(7));
            for (int j=i; j<Math.min(i+columns,shown.size()); j++) row.addView(appCell(shown.get(j)),new LinearLayout.LayoutParams(0,dp(91),1));
            while (row.getChildCount()<columns) row.addView(new View(this),new LinearLayout.LayoutParams(0,dp(91),1));
            appGrid.addView(row);
        }
        // Dock displays first four available apps for quick launch.
        for (int i=0; i<Math.min(4, allApps.size()); i++) {
            ResolveInfo ri=allApps.get(i);
            LinearLayout cell=vertical(); cell.setGravity(Gravity.CENTER);
            ImageView icon=new ImageView(this); try { icon.setImageDrawable(ri.loadIcon(pm)); } catch(Exception ignored){}
            cell.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));
            cell.setOnClickListener(v -> launch(ri));
            dock.addView(cell,new LinearLayout.LayoutParams(0,-1,1));
        }
    }

    View appCell(ResolveInfo ri) {
        LinearLayout cell=vertical(); cell.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        ImageView icon=new ImageView(this);
        try { icon.setImageDrawable(ri.loadIcon(pm)); } catch(Exception ignored){}
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(48),dp(48)); ip.gravity=Gravity.CENTER;
        cell.addView(icon,ip);
        TextView name=text(pm.getApplicationLabel(ri.activityInfo.applicationInfo).toString(),11,Color.WHITE,false);
        name.setGravity(Gravity.CENTER); name.setMaxLines(2); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(35)); np.setMargins(0,dp(4),0,0); cell.addView(name,np);
        cell.setOnClickListener(v -> launch(ri));
        return cell;
    }

    void launch(ResolveInfo ri) {
        try {
            Intent i=new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setClassName(ri.activityInfo.packageName,ri.activityInfo.name);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch(Exception e) {
            Toast.makeText(this,"تعذر فتح التطبيق",Toast.LENGTH_SHORT).show();
        }
    }
}